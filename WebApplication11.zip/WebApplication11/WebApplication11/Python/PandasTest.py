from statistics import mean
from scipy import stats
from scipy.stats import t
import numpy as np
import pandas as pd
import os
import csv
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import math

print(os.listdir(os.getcwd()))

routes = pd.read_csv('routes_meohad.csv')

def linReg(route):
  #additional data for selection and calculations later
  hypData = HypTest(route)
  #add maximum duration

  #devide into time periods
  h = route.D_Hours.iloc[0]
  if (h >= 7) & (h <= 9):
    hour = 0
  elif (h >= 10) & (h <= 15):
    hour = 1
  elif (h >= 16) & (h <= 19):
    hour = 2
  else: hour = 3

  data = {"Origin": route.origin.iloc[0], "Destination": route.destination.iloc[0],
           "Day": route.day.iloc[0], "Hour": hour,
           "Max_Duration": hypData["max"], "Mean": hypData["mean"], "RoutesCount": hypData["n"],
           "Sample_Variability": hypData["sv"], "Sample_SD": hypData["sd"], "T_Value": hypData["tv"]
           }
  #regression
  route.drop(['line', 'id', 'destination', 'origin', 'day', 'arrival', 'departure', 'D_Hours'], axis=1, inplace=True)
  
  X=route.drop(['duration'], axis=1) #columns used for prediction
  y=route['duration'] #value we want to predict
  X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1234)
  lm = LinearRegression() 
  lm.fit(X_train,y_train) 
  coeff_df = pd.DataFrame(lm.coef_, X.columns, columns=['Coefficient'])
  return coeff_df, data, lm.intercept_

def HypTest(route):
  routeTimes = route["duration"]
  routeTimes.to_numpy()
  ##(50 = מה שהרגירסיה ניבתה יותר נכון הזמן שהיא ניבתה שיקח לאוטובוס)
  SVariability = stats.tstd(routeTimes) 

  hypData = {
    "max": routeTimes.max(),
    "mean":mean(routeTimes), # routes mean
    "n":len(routeTimes), # number of routes
    "sv":SVariability, #Sample variability
    "sd":math.sqrt(SVariability), #Sample standard deviation
    "tv": t.ppf(0.15, df=len(routeTimes)) #t value
    }
  return hypData

#get unique values of origin and destination
origins = routes["origin"].unique() 
destinations = routes["destination"].unique()

#insert 
routes.insert(5, "D_Hours", 0)

sep_routes = []
for i in range(4):
    sep_routes.append(pd.DataFrame())

for i in range(routes.departure.size):
    if len(routes.departure[i]) == 5:
        routes.D_Hours[i] = int(routes.departure[i][0:2])
    else: routes.D_Hours[i] = int(routes.departure[i][0:1])


coeff_Arr = []
data_Arr = []
intercept_Arr = []

for x in range(len(origins)): # for every origin
  sep_origin = routes.loc[routes['origin'] == origins[x]]
  for y in range(len(destinations)): # for every destination
    sep_destination = sep_origin.loc[sep_origin['destination'] == destinations[y]]
    if sep_destination.size != 0: #if destination not found in DB, skip to the next destination
      for i in range(7): # for every day of the week
        sep_day = sep_destination.loc[sep_destination['day'] == i]
        if sep_day.size != 0: #if day not found in DB, skip to the next day
          sep_routes[0] = sep_day.loc[(sep_day['D_Hours'] <= 9 )& (sep_day["D_Hours"] >= 7)]
          sep_routes[1] = sep_day.loc[(sep_day['D_Hours'] <= 15 )& (sep_day["D_Hours"] >= 10)]
          sep_routes[2] = sep_day.loc[(sep_day['D_Hours'] <= 19 )& (sep_day["D_Hours"] >= 16)]
          sep_routes[3] = sep_day.loc[(sep_day['D_Hours'] <= 23 )& (sep_day["D_Hours"] >= 20)]
          for j in range(len(sep_routes)):
            if len(sep_routes[j].index) >= 2: #if DF has less than 2 rows, skip linear regression
              coeff, data, intercept = linReg(sep_routes[j]) # do linear regression
              coeff_Arr.append(coeff)
              data_Arr.append(data)
              intercept_Arr.append(intercept)

#divide into time periods
# origin -> destination -> day -> time range -> linear regression
# for x in range(len(origins)): # for every origin
#   sep_origin = routes.loc[routes['origin'] == origins[x]]
#   for y in range(len(destinations)): # for every destination
#     sep_destination = sep_origin.loc[sep_origin['destination'] == destinations[y]]
#     if sep_destination.size != 0: #if destination not found in DB, skip to the next destination
#       for i in range(7): # for every day of the week
#         sep_day = sep_destination.loc[sep_destination['day'] == i]
#         if sep_day.size != 0: #if day not found in DB, skip to the next day
#           sep_routes[0] = sep_day.loc[(sep_day['D_Hours'] <= 9 )& (sep_day["D_Hours"] >= 7)]
#           sep_routes[1] = sep_day.loc[(sep_day['D_Hours'] <= 15 )& (sep_day["D_Hours"] >= 10)]
#           sep_routes[2] = sep_day.loc[(sep_day['D_Hours'] <= 19 )& (sep_day["D_Hours"] >= 16)]
#           sep_routes[3] = sep_day.loc[(sep_day['D_Hours'] <= 23 )& (sep_day["D_Hours"] >= 20)]
#           for j in range(len(sep_routes)):
#             if len(sep_routes[j].index) >= 2: #if DF has less than 2 rows, skip linear regression
#               coeff, data, intercept = linReg(sep_routes[j]) # do linear regression
#               coeff_Arr.append(coeff)
#               data_Arr.append(data)
#               intercept_Arr.append(intercept)

#save data to csv
with open (os.getcwd() + '\coeffs.csv', 'w', newline='') as f:
      f_writer = csv.writer(f)
      f_writer.writerow([
        "Buses", "Stops", "Distance", "Rain","Intercept", "Origin", "Destination", "Day", "Hour",
        "Max_Duration", "Mean", "RoutesCount", "Sample_Variability", "Sample_SD", "T_Value"
      ])

for i in range(len(coeff_Arr)):
  with open (os.getcwd() + '\coeffs.csv', 'a', newline='') as f:
      f_writer = csv.writer(f)
      f_writer.writerow([
        coeff_Arr[i]['Coefficient'][0], coeff_Arr[i]['Coefficient'][1], coeff_Arr[i]['Coefficient'][2], 
        coeff_Arr[i]['Coefficient'][3], intercept_Arr[i] ,data_Arr[i]["Origin"], data_Arr[i]["Destination"], 
        data_Arr[i]["Day"], data_Arr[i]["Hour"], data_Arr[i]["Max_Duration"], data_Arr[i]["Mean"],
        data_Arr[i]["RoutesCount"], data_Arr[i]["Sample_Variability"], data_Arr[i]["Sample_SD"], 
        data_Arr[i]["T_Value"]
        ])