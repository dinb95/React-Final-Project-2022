﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication9.Models.DAL;

namespace WebApplication9.Models
{
    public class RouteRequest
    {
        public string Origin { get; set; }
        public string Destination { get; set; }
        public int Hour { get; set; }

        public void saveAllRoutes()
        {
            DataService ds = new DataService();
            ds.saveAllRoutes();
        }

        public RouteRequest(string origin, string destination, int hour)
        {
            Origin = origin;
            Destination = destination;
            Hour = hour;
        }

        public RouteRequest() { }

    }
}