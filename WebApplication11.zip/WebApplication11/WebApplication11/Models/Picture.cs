﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication9.Models
{
    public class Picture
    {
        public int id { get; set; }
        public string url { get; set; }

        public Picture () { }

        public Picture(int id, string url)
        {
            this.id = id;
            this.url = url;
        }
    }
}