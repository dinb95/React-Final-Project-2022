﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication9.Models.DAL
{
    public sealed class Scheduler
    {
        public Scheduler() { }
        public void Scheduler_Start()
        {
            DataService ds = new DataService();
            TimerCallback callbackDaily = new TimerCallback(UsersRoute.GetUsersRoutes); //pass function we want to execute
            Timer dailyTimer = new Timer(callbackDaily, null, TimeSpan.Zero, TimeSpan.FromSeconds(300));
        }
    }
}