﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication9.Models.DAL;

namespace WebApplication9.Models
{
    public class RouteData
    {
        string lineNumber;
        string origin;
        string destination;
        int day;
        int hour;
        string arrivalTime;
        string departureTime;
        int numOfBuses;
        int stops;
        int routeDuration;
        int routeDistance;
        float rain;

        public void insert()
        {
            DataService ds = new DataService();
            ds.insertRoute(this);
        }
        public List<double> usePredictiton()
        {
            DataService ds = new DataService();
            return ds.usePrediction(this);
        }

        public RouteData() { }

        public RouteData(string lineNumber, string origin, string destination, int day, string arrivalTime, string departureTime, int numOfBuses, int stops, int routeDuration, int routeDistance, float rain)
        {
            this.lineNumber = lineNumber;
            this.origin = origin;
            this.destination = destination;
            this.day = day;
            this.arrivalTime = arrivalTime;
            this.departureTime = departureTime;
            this.numOfBuses = numOfBuses;
            this.stops = stops;
            this.routeDuration = routeDuration;
            this.routeDistance = routeDistance;
            this.rain = rain;
        }

        public string LineNumber { get => lineNumber; set => lineNumber = value; }
        public int Day { get => day; set => day = value; }
        public string ArrivalTime { get => arrivalTime; set => arrivalTime = value; }
        public string DepartureTime { get => departureTime; set => departureTime = value; }
        public int NumOfBuses { get => numOfBuses; set => numOfBuses = value; }
        public int Stops { get => stops; set => stops = value; }
        public int RouteDuration { get => routeDuration; set => routeDuration = value; }
        public int RouteDistance { get => routeDistance; set => routeDistance = value; }
        public string Origin { get => origin; set => origin = value; }
        public string Destination { get => destination; set => destination = value; }
        public float Rain { get => rain; set => rain = value; }
        public int Hour { get => hour; set => hour = value; }
    }


}