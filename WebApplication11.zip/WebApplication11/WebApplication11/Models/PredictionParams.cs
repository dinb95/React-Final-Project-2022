﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication9.Models
{
    public class PredictionParams
    {
        float buses;
        float stops;
        float distance;
        float rain;
        float intercept;
        string origin;
        string destination;
        int day;
        int hour;
        int maxDuration;
        float mean;
        int routesCount;
        float sampleVar;
        float sampleSD;
        float t_Value;

        public float Buses { get => buses; set => buses = value; }
        public float Stops { get => stops; set => stops = value; }
        public float Distance { get => distance; set => distance = value; }
        public float Rain { get => rain; set => rain = value; }
        public string Origin { get => origin; set => origin = value; }
        public string Destination { get => destination; set => destination = value; }
        public int Day { get => day; set => day = value; }
        public int Hour { get => hour; set => hour = value; }
        public int MaxDuration { get => maxDuration; set => maxDuration = value; }
        public float Mean { get => mean; set => mean = value; }
        public int RoutesCount { get => routesCount; set => routesCount = value; }
        public float SampleVar { get => sampleVar; set => sampleVar = value; }
        public float SampleSD { get => sampleSD; set => sampleSD = value; }
        public float T_Value { get => t_Value; set => t_Value = value; }
        public float Intercept { get => intercept; set => intercept = value; }

        public PredictionParams() { }
        public PredictionParams(float buses, float stops, float distance, float rain, float intercept, string origin, string destination, int day, int hour, int maxDuration, float mean, int routesCount, float sampleVar, float sampleSD, float value)
        {
            this.buses = buses;
            this.stops = stops;
            this.distance = distance;
            this.rain = rain;
            this.intercept = intercept;
            this.origin = origin;
            this.destination = destination;
            this.day = day;
            this.hour = hour;
            this.maxDuration = maxDuration;
            this.mean = mean;
            this.routesCount = routesCount;
            this.sampleVar = sampleVar;
            this.sampleSD = sampleSD;
            t_Value = value;
        }
    }

}

