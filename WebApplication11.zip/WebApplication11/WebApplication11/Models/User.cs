﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication9.Models.DAL;

namespace WebApplication9.Models
{
    public class User
    {
        int id;
        string firstName;
        string lastName;
        string email;
        string password;
        public int Id { get => id; set => id = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string Email { get => email; set => email = value; }
        public string Password { get => password; set => password = value; }
        public User() { }

        public User(string firstName, string lastName, string email, string password)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.email = email;
            this.password = password;
            Id = -1;
        }
        /* Insert a new user to the User Tbl */
        public int Insert()
        {
            DataService us = new DataService();
            if (us.InsertUser(this))
                return us.getUserId(this);
            else return -1; 
        }

        /* Get User when login to the system, if the user exists - return him */
        public User checkLogin(string email, string pass)
        {
            DataService us = new DataService();
            return us.checkLogIn(email, pass);
        }
        /* Update User Details to the Users Tbl */
        public int UpdateUser()
        {
            DataService us = new DataService();
            return us.UpdateUser(this); //return 1/-1;
        }
        public User GetById(int id)
        {
            DataService ds = new DataService();
            return ds.GetById(id);

        }
    }
}