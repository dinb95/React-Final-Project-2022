﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication9.Models.DAL;

namespace WebApplication9.Models
{
    public sealed class UsersRoute
    {
        public UsersRoute() { }

        public static void GetUsersRoutes(object state)
        {
            DataService ds = new DataService();
            PrefRoute prList = ds.GetUsersRoutes();

            if (prList is null)
            {

            }
        }
    }
}