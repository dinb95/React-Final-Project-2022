﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Configuration;

namespace WebApplication9.Models.DAL
{
    public class DataService
    {
        //save all routes data from DB to csv
        public void saveAllRoutes()
        {  
            List<RouteData> rdList = new List<RouteData>();
            SqlConnection con = null;

            DataTable table = new DataTable();

            table.Columns.Add("id", typeof(int));
            table.Columns.Add("line", typeof(string));
            table.Columns.Add("day", typeof(int));
            table.Columns.Add("arrival", typeof(string));
            table.Columns.Add("departure", typeof(string));
            table.Columns.Add("buses", typeof(int));
            table.Columns.Add("stops", typeof(int));
            table.Columns.Add("duration", typeof(int));
            table.Columns.Add("distance", typeof(int));
            table.Columns.Add("origin", typeof(string));
            table.Columns.Add("destination", typeof(string));
            table.Columns.Add("rain", typeof(float));

            try
            {
                con = connect("DBConnectionString"); // create a connection to the database using the connection String defined in the web config file

                String selectSTR = "select * from Routetimes";
                SqlCommand cmd = new SqlCommand(selectSTR, con);

                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end

                while (dr.Read())
                {   // Read till the end of the data into a row
                    RouteData data = new RouteData();
                    data.LineNumber = (string)dr["lineNumber"];
                    data.Day = Convert.ToInt32(dr["day"]);
                    data.ArrivalTime = (string)dr["arrivalTime"];
                    data.DepartureTime = (string)dr["departureTime"];
                    data.NumOfBuses = Convert.ToInt32(dr["numOfBuses"]);
                    data.Stops = Convert.ToInt32(dr["stops"]);
                    data.RouteDuration = Convert.ToInt32(dr["routeDuration"]);
                    data.RouteDistance = Convert.ToInt32(dr["routeDistance"]);
                    data.Origin = (string)dr["origin"];
                    data.Destination = (string)dr["destination"];

                    table.Rows.Add(Convert.ToInt32(dr["routeId"]), data.LineNumber, data.Day, data.ArrivalTime,
                        data.DepartureTime, data.NumOfBuses, data.Stops, data.RouteDuration, data.RouteDistance,
                        data.Origin, data.Destination, Convert.ToSingle(dr["Rain"]));
                }
                //string path = "C:\\Users\\dinen\\OneDrive\\Desktop\\FinalProject\\Python\\routes.csv";
                string path = @"C:\Users\dinen\source\repos\WebApplication11\WebApplication11\Python\routes.csv";
                ToCSV(table, path);
            }
            catch (Exception ex)
            {
                // write to log
                throw (ex);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }

            }
        }
        ///////////////////////////???////////////////////////////////////
        public List<double> usePrediction(RouteData rd)
        {
            List<double> returns = new List<double>();
            PredictionParams predParams = GetPredictionParams(rd);
            if (predParams == null)
                return null;
            
                double pred = useReggresion(predParams, rd);
                double Tx = t_test(predParams, rd);

                returns.Add(pred); //0
                returns.Add(Tx); ;//1
                returns.Add(predParams.T_Value); //2


                if (Tx <= predParams.T_Value)//3
                    returns.Add(0); // reject h0, accept h1 
                else returns.Add(1); // accept h0

                returns.Add(predParams.SampleSD); //4
                returns.Add(predParams.SampleVar);//5
                returns.Add(predParams.Mean);//6    

                return returns;
        }
        //T-test function according a reggresion
        public double t_test(PredictionParams predictionParams, RouteData rd)
        {
            float sAvg = predictionParams.Mean;
            float pAvg = useReggresion(predictionParams, rd);
            float sd = predictionParams.SampleVar;
            int n = predictionParams.RoutesCount;
            double Tx = ((sAvg - pAvg) / (sd / Math.Sqrt(n)));
            return Tx;
        }
        // calc a pAvg (the value we predict) 
        //The purpose of the linear regression - time that we predict for the chosen path
        public float useReggresion(PredictionParams predictionParams, RouteData rd)
        {
            float regression = predictionParams.Intercept + ((predictionParams.Buses * rd.NumOfBuses) + (predictionParams.Stops * rd.Stops) +
                (predictionParams.Distance * rd.RouteDistance) + (predictionParams.Rain * rd.Rain));
            return regression;
        }
        //get the relevant parameters from csv, according to the route selected by the user
        public PredictionParams GetPredictionParams(RouteData rd)
        {
            string fileList = GetCSV("https://proj.ruppin.ac.il/bgroup54/test2/tar6/Pages/coeffs.csv");
            List<PredictionParams> ppl = new List<PredictionParams>();
            if (rd.Hour >= 7 && rd.Hour <= 9)
                rd.Hour = 0;
            else if (rd.Hour >= 10 && rd.Hour <= 15)
                rd.Hour = 1;
            else if (rd.Hour >= 16 && rd.Hour <= 19)
                rd.Hour = 2;
            else rd.Hour = 3;

            string[] lines = fileList.Split(
                new string[] { Environment.NewLine },
                StringSplitOptions.None
            );
            foreach (string line in lines)
            {
                string[] columns = line.Split(',');

                if (rd.Origin == columns[5] && rd.Destination == columns[6] && rd.Day == Convert.ToInt32(columns[7]) && rd.Hour == Convert.ToInt32(columns[8]))
                {
                    PredictionParams predictionParams = new PredictionParams();
                    predictionParams.Buses = Convert.ToSingle(columns[0]);
                    predictionParams.Stops = Convert.ToSingle(columns[1]);
                    predictionParams.Distance = Convert.ToSingle(columns[2]);
                    predictionParams.Rain = Convert.ToSingle(columns[3]);
                    predictionParams.Intercept = Convert.ToSingle(columns[4]);
                    predictionParams.Origin = (string)columns[5];
                    predictionParams.Destination = (string)columns[6];
                    predictionParams.Day = Convert.ToInt32(columns[7]);
                    predictionParams.Hour = Convert.ToInt32(columns[8]);
                    predictionParams.MaxDuration = Convert.ToInt32(columns[9]);
                    predictionParams.Mean = Convert.ToSingle(columns[10]);
                    predictionParams.RoutesCount = Convert.ToInt32(columns[11]);
                    predictionParams.SampleVar = Convert.ToSingle(columns[12]);
                    predictionParams.SampleSD = Convert.ToSingle(columns[13]);
                    predictionParams.T_Value = Convert.ToSingle(columns[14]);

                    return predictionParams;
                }

            }
            return null;
        }
        public int postRoute(PrefRoute pr)
        {
            SqlConnection con;
            SqlCommand cmd;

            try
            {
                con = connect("DBConnectionString"); // create the connection
            }
            catch (Exception ex)
            {
                // write to log
                throw (ex);
            }

            String cStr = BuildInsertCommand(pr);      // helper method to build the insert string

            cmd = CreateCommand(cStr, con);             // create the command

            try
            {
                int numEffected = cmd.ExecuteNonQuery();
                // execute the command
                return numEffected;
            }
            catch (Exception ex)
            {
                // write to log
                throw (ex);
            }

            finally
            {
                if (con != null)
                {
                    // close the db connection
                    con.Close();
                }
            }
        }

        public PrefRoute GetUsersRoutes()
        {
            //get all routes of the users that are set to departure today
            List<PrefRoute> prList = new List<PrefRoute>();
            SqlConnection con = null;
            DateTime dt = DateTime.Today;
            string today = dt.ToString("MM-dd-yyyy");
            PrefRoute pr = new PrefRoute();
            RouteData rd = new RouteData();
            PredictionParams pp = new PredictionParams();

            try
            {
                con = connect("DBConnectionString"); // create a connection to the database using the connection String defined in the web config file

                String selectSTR = "select * from Timely_Routes where userId=2 and [Date]='" + today + "' order by [Datetime]";
                SqlCommand cmd = new SqlCommand(selectSTR, con);

                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end

                if (dr.Read())
                {   // Read till the end of the data into a row
                    rd.LineNumber = (string)dr["LineNumber"];
                    rd.Origin = (string)dr["Origin"];
                    rd.Destination = (string)dr["Destination"];
                    rd.ArrivalTime = (string)dr["ArrivalTime"];
                    rd.DepartureTime = (string)dr["DepartureTime"];
                    rd.RouteDuration = Convert.ToInt32(dr["RouteDuration"]);
                    pr.date = (string)dr["Datetime"].ToString();
                    pp.SampleSD = Convert.ToSingle(dr["SampleSD"]);
                    pp.SampleVar = Convert.ToSingle(dr["SampleVar"]);
                    pr.alarmClock = Convert.ToInt32(dr["alarmClock"]);
                    pr.testTime = Convert.ToSingle(dr["TestTime"]);
                    pr.userId = (string)dr["userId"];

                    pr.routeData = rd;
                    pr.predParams = pp;
                  
                }
                return pr;

            }
            catch (Exception ex)
            {
                // write to log
                throw (ex);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }

            }
        }
        //--------------------------------------------------------------------------------------------------
        // This method inserts a user to the Users table 
        //--------------------------------------------------------------------------------------------------
        public bool InsertUser(User user)
        {
            SqlConnection con;
            SqlCommand cmd;
            try
            {
                con = connect("DBConnectionString"); // create the connection
                //checking if the email already exists
                String selectSTR = "SELECT * FROM Timely_Users WHERE email = '" + user.Email + "'";
                cmd = new SqlCommand(selectSTR, con);

                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end

                while (dr.Read())
                {
                    if (dr.HasRows)
                        return false;

                }
            }
            catch (Exception ex)
            {
                // write to log
                throw (ex);
            }
            con = connect("DBConnectionString"); // create the connection
            String cStr = BuildInsertCommand(user);      // helper method to build the insert string
            cmd = CreateCommand(cStr, con);             // create the command

            try
            {
                int numEffected = cmd.ExecuteNonQuery(); // execute the command
                return true;
            }
            catch (Exception ex)
            {
                // write to log
                throw (ex);
            }

            finally
            {
                if (con != null)
                {
                    // close the db connection
                    con.Close();
                }
            }

        }

        //--------------------------------------------------------------------
        // Build the Insert command String
        //--------------------------------------------------------------------
        private String BuildInsertCommand(User user)
        {
            String command;

            StringBuilder sb = new StringBuilder();
            // use a string builder to create the dynamic string
            sb.AppendFormat("Values('{0}', '{1}', '{2}', '{3}')", user.FirstName, user.LastName, user.Email, user.Password);
            String prefix = "INSERT INTO Timely_Users " + "([firstName], [lastName], [email], [password]) ";
            command = prefix + sb.ToString();

            return command;
        }
        //---------------------------------------------------------------------------------
        // Get user by Id from Users Tbl
        //---------------------------------------------------------------------------------
        public User GetById(int id)
        {
            SqlConnection con = null;
            SqlCommand cmd;

            try
            {
                con = connect("DBConnectionString"); // create the connection
                //checking if the email already exists
                String selectSTR = "SELECT * FROM Timely_Users WHERE userId =" + id;
                cmd = new SqlCommand(selectSTR, con);

                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end
                User u = new User();
                if (dr.Read())
                {
                    u.Id = Convert.ToInt32(dr["userId"]);
                    u.FirstName = (string)dr["firstName"];
                    u.LastName = (string)dr["lastName"];
                    u.Password = (string)dr["password"];
                }
                return u;
            }

            catch (Exception ex)
            {
                // write to log
                throw (ex);
            }

            finally
            {
                if (con != null)
                {
                    // close the db connection
                    con.Close();
                }
            }
        }
        public int getUserId(User user)
        {
            int id = -1;
            SqlConnection con = null;
            SqlCommand cmd;
            try
            {
                con = connect("DBConnectionString"); // create the connection
                //checking if the email already exists
                String selectSTR = "SELECT userId FROM Timely_Users WHERE email = '" + user.Email + "'";
                cmd = new SqlCommand(selectSTR, con);

                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end
                User u = null;
                if (dr.Read())
                {
                    id = Convert.ToInt32(dr["userId"]);

                }
                return id;
            }

            catch (Exception ex)
            {
                throw (ex);
            }

            finally
            {
                if (con != null)
                {
                    // close the db connection
                    con.Close();
                }
            }
        }
        //---------------------------------------------------------------------------------
        // This method check if the user exists in the Users table
        // And return this user if he exists
        //---------------------------------------------------------------------------------
        public User checkLogIn(string email, string pass)
        {
            SqlConnection con = null;
            SqlCommand cmd;
            try
            {
                con = connect("DBConnectionString"); // create the connection
                //checking if the email already exists
                String selectSTR = "SELECT * FROM Timely_Users WHERE email = '" + email + "'AND password= '" + pass + "'";
                cmd = new SqlCommand(selectSTR, con);

                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end
                User u = null;
                if (dr.Read())
                {
                    u = new User();
                    u.Id = Convert.ToInt32(dr["userId"]);
                    u.FirstName = (string)dr["firstName"];
                    u.LastName = (string)dr["lastName"];
                    u.Email = (string)dr["email"];
                }
                return u;
            }

            catch (Exception ex)
            {
                throw (ex);
            }

            finally
            {
                if (con != null)
                {
                    // close the db connection
                    con.Close();
                }
            }
        }
        public int savePic(Picture picture)
        {
            SqlConnection con;
            SqlCommand cmd;

            try
            {
                con = connect("DBConnectionString"); // create the connection
            }
            catch (Exception ex)
            {
                // write to log
                throw (ex);
            }

            String cStr = BuildInsertCommand(picture);      // helper method to build the insert string

            cmd = CreateCommand(cStr, con);             // create the command

            try
            {
                int numEffected = cmd.ExecuteNonQuery();
                // execute the command
                return numEffected;
            }
            catch (Exception ex)
            {
                // write to log
                throw (ex);
            }

            finally
            {
                if (con != null)
                {
                    // close the db connection
                    con.Close();
                }
            }
        }
        public string GetUserPic(int id)
        {
            SqlConnection con = null;
            SqlCommand cmd;
            string picUrl = "";
            try
            {
                con = connect("DBConnectionString"); // create the connection
                //checking if the email already exists
                String selectSTR = "SELECT picUrl FROM Timely_Pics WHERE userId =" + id;
                cmd = new SqlCommand(selectSTR, con);

                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end
                User u = null;
                if (dr.Read())
                {
                    picUrl = (string)dr["picUrl"];
                }
                return picUrl;
            }

            catch (Exception ex)
            {
                throw (ex);
            }

            finally
            {
                if (con != null)
                {
                    // close the db connection
                    con.Close();
                }
            }
        }
        //add new row to DB
        public int insertRoute(RouteData rd)
        {
            SqlConnection con;
            SqlCommand cmd;

            try
            {
                con = connect("DBConnectionString"); // create the connection
            }
            catch (Exception ex)
            {
                // write to log
                throw (ex);
            }

            String cStr = BuildInsertCommand(rd);      // helper method to build the insert string

            cmd = CreateCommand(cStr, con);             // create the command

            try
            {
                int numEffected = cmd.ExecuteNonQuery();
                // execute the command
                return numEffected;
            }
            catch (Exception ex)
            {
                // write to log
                throw (ex);
            }

            finally
            {
                if (con != null)
                {
                    // close the db connection
                    con.Close();
                }
            }
        }
        public int newRoute(int routeId, PrefRoute route)
        {
            SqlConnection con;
            SqlCommand cmd;
            {
                try
                {
                    con = connect("DBConnectionString"); // create the connection
                }
                catch (Exception ex)
                {
                    // write to log
                    throw (ex);
                }

                String cStr = BuildUpdateCommand(routeId, route);      // helper method to build the insert string

                cmd = CreateCommand(cStr, con);             // create the command

                try
                {
                    int rowEffected = cmd.ExecuteNonQuery(); // execute the command
                    return rowEffected;
                }
                catch (Exception ex)
                {
                    // write to log
                    throw (ex);
                }

                finally
                {
                    if (con != null)
                    {
                        // close the db connection
                        con.Close();
                    }
                }
            }

        }
        //--------------------------------------------------------------------
        // Build the Update command String
        //--------------------------------------------------------------------
        //---------------------------------------------------------------------------------
        // Update User Details to the Users Tbl
        //---------------------------------------------------------------------------------
        public int UpdateUser(User user)
        {
            SqlConnection con;
            SqlCommand cmd;
            {
                try
                {
                    con = connect("DBConnectionString"); // create the connection
                }
                catch (Exception ex)
                {
                    // write to log
                    throw (ex);
                }

                String cStr = BuildUpdateCommand(user);      // helper method to build the insert string

                cmd = CreateCommand(cStr, con);             // create the command

                try
                {
                    int rowEffected = cmd.ExecuteNonQuery(); // execute the command
                    return rowEffected;
                }
                catch (Exception ex)
                {
                    // write to log
                    throw (ex);
                }

                finally
                {
                    if (con != null)
                    {
                        // close the db connection
                        con.Close();
                    }
                }
            }
        }
        private String BuildUpdateCommand(User user)
        {
            String command;

            StringBuilder sb = new StringBuilder();
            // use a string builder to create the dynamic string
            sb.AppendFormat(" SET [FirstName]='{0}', [LastName]='{1}', [Password]='{2}' ", user.FirstName, user.LastName, user.Password);
            String prefix = "UPDATE Timely_Users" + " ";
            String end = "WHERE userId=" + user.Id;
            command = prefix + sb.ToString() + end;
            return command;
        }
        private String BuildInsertCommand(Picture picture)
        {
            String command;

            StringBuilder sb = new StringBuilder();
            // use a string builder to create the dynamic string
            sb.AppendFormat("Values('{0}', '{1}')", picture.id, picture.url);
            String prefix = "INSERT INTO Timely_Pics " + "([userId], [picUrl]) ";
            command = prefix + sb.ToString();

            return command;
        }
        private String BuildUpdateCommand(int routeId, PrefRoute route)
        {
            String command;
            String prefix = "UPDATE Timely_Routes set [LineNumber]=('" + route.routeData.LineNumber + "'),[Origin]=('" + route.routeData.Origin + "'),";
            prefix += "[Destination]=('" + route.routeData.Destination + "'),[ArrivalTime]=('" + route.routeData.ArrivalTime + "'),[DepartureTime]=('" + route.routeData.DepartureTime + "'),";
            prefix += "[RouteDuration]=(" + route.routeData.RouteDuration + "),[Datetime]=('" + route.date + " " + route.timeTarget + "'),[SampleSD]=(" + route.predParams.SampleSD + "),";
            prefix += "[SampleVar]=(" + route.predParams.SampleVar + "),[Mean]=(" + route.predParams.Mean + "),[alarmClock]=(" + route.alarmClock + "),[TestTime]=(" + route.testTime + "), ";//[userId]=[userId]+("+ route.userId+"),
            prefix += "[Hour]=(" + route.routeData.Hour + "),[Day]=(" + route.routeData.Day + "),[NumOfBuses]=(" + route.routeData.NumOfBuses + "), [Stops]=(" + route.routeData.Stops + "),[RouteDistance]=(" + route.routeData.RouteDistance + "),";
            prefix += "[Rain]=(" + route.routeData.Rain + ")";
            String end = " WHERE routeId= " + routeId;
            command = prefix + end;
            return command;
        }
        private String BuildInsertCommand(RouteData rd)
        {
            String command;

            StringBuilder sb = new StringBuilder();
            // use a string builder to create the dynamic string
            sb.AppendFormat("Values('{0}', '{1}', '{2}', '{3}','{4}','{5}','{6}','{7}', '{8}', '{9}', '{10}')",
                rd.LineNumber, rd.Day, rd.ArrivalTime, rd.DepartureTime, rd.NumOfBuses, rd.Stops, rd.RouteDuration, rd.RouteDistance, rd.Origin, rd.Destination, rd.Rain);
            String prefix = "INSERT INTO RouteTimes " + "([lineNumber], [day], [arrivalTime], [departureTime], [numOfBuses], [stops], [routeDuration], [routeDistance], [origin], [destination], [Rain]) ";
            command = prefix + sb.ToString();

            return command;
        }
        private String BuildInsertCommand(PrefRoute pr)
        {
            String command;

            StringBuilder sb = new StringBuilder();
            // use a string builder to create the dynamic string
            // numofbuses, stops, distance, rain
            sb.AppendFormat("Values('{0}', '{1}', '{2}', '{3}','{4}','{5}','{6}','{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14}', '{15}', '{16}', '{17}', '{18}', '{19}')",
                pr.routeData.LineNumber, pr.routeData.Origin, pr.routeData.Destination,pr.routeData.Day,pr.routeData.Hour, pr.routeData.ArrivalTime,
                pr.routeData.DepartureTime ,pr.routeData.NumOfBuses ,pr.routeData.Stops ,pr.routeData.RouteDuration, pr.routeData.RouteDistance,pr.routeData.Rain, (pr.date + " " + pr.timeTarget), pr.date, pr.predParams.SampleSD,
                pr.predParams.SampleVar, pr.predParams.Mean, pr.alarmClock, calculateTestTime(pr), pr.userId);
            String prefix = "INSERT INTO Timely_Routes " + "([LineNumber], [Origin], [Destination],[Day],[Hour], [ArrivalTime], [DepartureTime],[NumOfBuses],[Stops], [RouteDuration], [RouteDistance] ,[Rain] , [Datetime], [Date], [SampleSD], [SampleVar], [Mean], [alarmClock], [TestTime], [userId]) ";
            command = prefix + sb.ToString();

            return command;
        }
        public SqlConnection connect(String conString)
        {

            // read the connection string from the configuration file
            string cStr = WebConfigurationManager.ConnectionStrings[conString].ConnectionString;
            SqlConnection con = new SqlConnection(cStr);
            con.Open();
            return con;
        }
        private SqlCommand CreateCommand(String CommandSTR, SqlConnection con)
        {

            SqlCommand cmd = new SqlCommand(); // create the command object

            cmd.Connection = con;              // assign the connection to the command object

            cmd.CommandText = CommandSTR;      // can be Select, Insert, Update, Delete 

            cmd.CommandTimeout = 10;           // Time to wait for the execution' The default is 30 seconds

            cmd.CommandType = System.Data.CommandType.Text; // the type of the command, can also be stored procedure

            return cmd;
        }
        public void ToCSV(DataTable dtDataTable, string strFilePath)
        {
            StreamWriter sw = new StreamWriter(strFilePath, false);
            //headers    
            for (int i = 0; i < dtDataTable.Columns.Count; i++)
            {
                sw.Write(dtDataTable.Columns[i]);
                if (i < dtDataTable.Columns.Count - 1)
                {
                    sw.Write(",");
                }
            }
            sw.Write(sw.NewLine);
            foreach (DataRow dr in dtDataTable.Rows)
            {
                for (int i = 0; i < dtDataTable.Columns.Count; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        string value = dr[i].ToString();
                        if (value.Contains(','))
                        {
                            value = String.Format("\"{0}\"", value);
                            sw.Write(value);
                        }
                        else
                        {
                            sw.Write(dr[i].ToString());
                        }
                    }
                    if (i < dtDataTable.Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
            }
            sw.Close();
        }

        public double calculateTestTime(PrefRoute pr)
        {
            if(pr.alarmClock == 0)
            {
                return Math.Ceiling((pr.predParams.Mean + pr.predParams.SampleVar + pr.predParams.SampleSD * 5) / 60);
            }
            else
            {
                return Math.Ceiling((pr.predParams.Mean + pr.predParams.SampleVar + pr.alarmClock + pr.predParams.SampleSD * 3)/60);
            }
        }
        public string GetCSV(string url)
        {
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
            HttpWebResponse resp = (HttpWebResponse)req.GetResponse();

            StreamReader sr = new StreamReader(resp.GetResponseStream());
            string results = sr.ReadToEnd();
            sr.Close();

            return results;
        }
    }

}