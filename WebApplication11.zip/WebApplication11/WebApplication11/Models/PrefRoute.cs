﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication9.Models.DAL;

namespace WebApplication9.Models
{
    public class PrefRoute
    {
        public RouteData routeData { get; set; }
        public string date { get; set; }
        public string timeTarget { get; set; }
        public PredictionParams predParams { get; set; }
        public int alarmClock { get; set; }
        public float testTime { get; set; }
        public string userId { get; set; }


        public PrefRoute() { }
        public PrefRoute(RouteData routeData, PredictionParams predParams, int alarmClock, string userId, string date, string timeTarget, float testTime)
        {
            this.routeData = routeData;
            this.predParams = predParams;
            this.alarmClock = alarmClock;
            this.userId = userId;
            this.date = date;
            this.timeTarget = timeTarget;
            this.testTime = testTime;
        } 

        public void postRoute()
        {
            DataService ds = new DataService();
            ds.postRoute(this);
        }
        public PrefRoute GetUserRoutes(int id)
        {
            DataService ds = new DataService();
            return ds.GetUsersRoutes();
        }
        public void Put(int id)
        {
            DataService db = new DataService();
            db.newRoute(id, this);
        }
    }
}