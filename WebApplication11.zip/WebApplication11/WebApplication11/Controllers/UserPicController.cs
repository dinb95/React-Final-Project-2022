﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApplication9.Models;
using WebApplication9.Models.DAL;

namespace WebApplication9.Controllers
{
    public class UserPicController : ApiController
    {
        // GET api/<controller>
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<controller>/5
        public string Get(int id)
        {
            DataService ds = new DataService();
            return ds.GetUserPic(id);
        }

        // POST api/<controller>
        public void Post([FromBody] Picture picture)
        {
            DataService ds = new DataService();
            ds.savePic(picture);
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}